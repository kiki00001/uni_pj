package com.ljw.map;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

public class MapTest extends MapActivity{
  
	MapView mapView;
	MapController mapController;
	AlertDialog.Builder mMapModeDialog = null;
	AlertDialog.Builder mSearchDialog = null;
	final int OPTIONS_MENU_MAP_MODE = 0;
	final int OPTIONS_MENU_MY_PLACE = 1;
	final int OPTIONS_MENU_SEARCH = 2;
	final int DIALOG_MAP_MODE = 0;
	final int DIALOG_SEARCH = 1;
	Context mContext;
	MyOverlay mMyOverlay;
	SitesOverlay mSitesOverlay;
	LocationManager mLocationManager;
	LocationProvider mLocationProvider;
	Toast mToast;
	public TextView mMyLocationEditText;
	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
        mContext = this;
        mapView = (MapView)findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        mapView.setSatellite(false);	//���� ��
        mapView.setStreetView(true);	//��Ʈ�� ��
        mapView.setTraffic(false);	//���� ���뷮
        mapController = mapView.getController();
        
        
        mMyOverlay = new MyOverlay(mContext, mapView);
        mapView.getOverlays().add(mMyOverlay);
        
        Drawable marker = getResources().getDrawable(R.drawable.mark);
		marker.setBounds(0, 0, marker.getIntrinsicWidth(), marker.getIntrinsicHeight());
        mSitesOverlay = new SitesOverlay(mContext, marker);
        mapView.getOverlays().add(mSitesOverlay);
        
        mLocationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);	//��Ȯ��
        criteria.setPowerRequirement(Criteria.POWER_LOW);	//��������
        criteria.setAltitudeRequired(false);	//�ع�
        criteria.setBearingRequired(false);	//��ħ�� ����
        criteria.setSpeedRequired(false);	//�ӵ�
        criteria.setCostAllowed(false);		//���
        
        mLocationProvider = mLocationManager.getProvider(mLocationManager.getBestProvider(criteria, true));
        
        addresses = new ArrayList<String>();
		addressLocations = new ArrayList<AddressLocation>();
		
		mMyLocationEditText = (TextView) getLayoutInflater().inflate(R.layout.my_location_text_view, null);
		
		MapView.LayoutParams geoLP = new MapView.LayoutParams(MapView.LayoutParams.FILL_PARENT,
				MapView.LayoutParams.WRAP_CONTENT,
				0, 0,
				MapView.LayoutParams.TOP);
		mapView.addView(mMyLocationEditText, geoLP);
		mMyLocationEditText.setSelected(true);
    }
    
    public void onResume()
    {
    	super.onResume();
    	mMyOverlay.enableCompass();
    	mMyOverlay.enableMyLocation();
    	//mLocationManager.requestLocationUpdates(mLocationProvider.getName(), 10000, 1, this);
    }
    
    public void onPause()
    {
    	super.onPause();
    	mMyOverlay.disableCompass();
    	mMyOverlay.disableMyLocation();
    	//mLocationManager.removeUpdates(this);
    }
    
    public void onDestroy()
    {
    	super.onDestroy();
    	mapView.getOverlays().remove(mMyOverlay);
    	mapView.getOverlays().remove(mSitesOverlay);
    }
    
	protected boolean isRouteDisplayed() 
	{
		return false;	//���� ��Ƽ��Ƽ�� ���� ������ ǥ���ϰ� �ִٸ� �ݵ�� true�� �����ؾ���. �׷��� ������ false ����
	}
	
	public boolean onCreateOptionsMenu(Menu menu)
	{
		menu.add(0, OPTIONS_MENU_MAP_MODE, OPTIONS_MENU_MAP_MODE, getString(R.string.map_mode)).setIcon(android.R.drawable.ic_menu_mapmode);
		menu.add(1, OPTIONS_MENU_MY_PLACE, OPTIONS_MENU_MY_PLACE, getString(R.string.my_place)).setIcon(android.R.drawable.ic_menu_myplaces);
		menu.add(1, OPTIONS_MENU_SEARCH, OPTIONS_MENU_SEARCH, getString(R.string.search)).setIcon(android.R.drawable.ic_menu_search);
		
		return super.onCreateOptionsMenu(menu);
	}
	
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId())
		{
		case OPTIONS_MENU_MAP_MODE:
			showDialog(DIALOG_MAP_MODE);
			break;
		case OPTIONS_MENU_MY_PLACE:
			updateMyPlace();
			break;
		case OPTIONS_MENU_SEARCH:
			showDialog(DIALOG_SEARCH);
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private void updateMyPlace()
	{
		if(mMyOverlay.getMyLocation() == null)
			Toast.makeText(mContext, getString(R.string.no_my_place), Toast.LENGTH_SHORT).show();
		else
		{
			mapController.animateTo(mMyOverlay.getMyLocation());
			if(mapView.isSatellite())
				mapController.setZoom(mapView.getMaxZoomLevel()-5);
			else
				mapController.setZoom(mapView.getMaxZoomLevel());
		}
	}
	
	public void showToast(String text)
	{
		if (mToast == null) {
			mToast = Toast.makeText(mContext, "", Toast.LENGTH_LONG);
		} else {
			mToast.cancel();
		}
		mToast.setText(text);
		mToast.setDuration(Toast.LENGTH_LONG);
		mToast.show();
	}
	
	protected Dialog onCreateDialog(int optionPopupDialogId)
	{
		switch(optionPopupDialogId)
		{
		case DIALOG_MAP_MODE:
			CharSequence[] mapModeList =
			{
				getString(R.string.satellite),
				getString(R.string.street),
				getString(R.string.traffic)
			};
			boolean[] itemChecked = 
			{
				mapView.isSatellite()?true:false,
				mapView.isStreetView()?true:false,
				mapView.isTraffic()?true:false
			};
			mMapModeDialog = new AlertDialog.Builder(mContext);
			mMapModeDialog.setTitle(R.string.map_mode);
			mMapModeDialog.setMultiChoiceItems(mapModeList, itemChecked, mMultiChoiceClickListener);
			mMapModeDialog.setPositiveButton(getString(R.string.ok), new OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					dialog.dismiss();
				}
			});
			return mMapModeDialog.create();
		case DIALOG_SEARCH:
			final EditText et = new EditText(mContext);
			ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			et.setTextSize(20);
			et.setLayoutParams(params);
			mSearchDialog = new AlertDialog.Builder(mContext);
			mSearchDialog.setTitle(R.string.search);
			mSearchDialog.setView(et);
			mSearchDialog.setPositiveButton(getString(R.string.ok), new OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					showAddressListFromLocationName(et.getText().toString());
					dialog.dismiss();
				}
			});
			mSearchDialog.setNegativeButton(getString(R.string.cancel), new OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					dialog.dismiss();
				}
			});
			return mSearchDialog.create();
		default:
			break;
		}
		
		return null;
	}
	
	ArrayList<String> addresses;
	ArrayList<AddressLocation> addressLocations;
	private class AddressLocation
	{
		public Double lat;
		public Double lng;
		AddressLocation(Double lat, Double lng)
		{
			this.lat = lat;
			this.lng = lng;
		}
	}
	private void showAddressListFromLocationName(String address)
	{
		Geocoder gc = new Geocoder(this, Locale.getDefault());
		
		try {
			List<Address> result =  gc.getFromLocationName(address, 10);
			if(result == null || result.size() < 1)
			{
				Toast.makeText(mContext, getString(R.string.no_address), Toast.LENGTH_SHORT).show();
				return;
			}
			addresses.clear();
			addressLocations.clear();
			for(int i = 0 ; i < result.size() ; i++)
			{
				Address item = result.get(i);
				StringBuilder string = new StringBuilder();
				for(int j = 0 ; j <= item.getMaxAddressLineIndex() ; j++)
				{
					if(j > 0)
						string.append(" ");
					string.append(item.getAddressLine(j));
				}
				
				addresses.add(string.toString());
				addressLocations.add(new AddressLocation(item.getLatitude(), item.getLongitude()));
			}
			
			ArrayAdapter<String> mAdapter = new ArrayAdapter<String>(mContext, android.R.layout.select_dialog_item, addresses);
			AlertDialog.Builder addressDialog = new AlertDialog.Builder(mContext);
			addressDialog.setTitle(R.string.search_result);
			addressDialog.setAdapter(mAdapter, mOnClickListener);
			
//			addressDialog.setPositiveButton(getString(R.string.go), new OnClickListener() {
//				public void onClick(DialogInterface dialog, int whichButton)
//				{
//				}
//			});
//			addressDialog.setNegativeButton(getString(R.string.cancel), new OnClickListener() {
//				public void onClick(DialogInterface dialog, int whichButton)
//				{
//					dialog.dismiss();
//				}
//			});
			addressDialog.create().show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private DialogInterface.OnClickListener mOnClickListener =
		new DialogInterface.OnClickListener()
	{
		public void onClick(DialogInterface dialog, int which) 
		{
			Double geoLat = addressLocations.get(which).lat * 1E6;
			Double geoLng = addressLocations.get(which).lng * 1E6;
			GeoPoint point = new GeoPoint(geoLat.intValue(), geoLng.intValue());
			mapController.animateTo(point);
			if(mapView.isSatellite())
				mapController.setZoom(mapView.getMaxZoomLevel()-6);
			else
				mapController.setZoom(mapView.getMaxZoomLevel());
			
//			Drawable marker = getResources().getDrawable(R.drawable.mark);
//			marker.setBounds(0, 0, marker.getIntrinsicWidth(), marker.getIntrinsicHeight());
//			mapView.getOverlays().add(new SitesOverlay(marker, point));
			mSitesOverlay.addItem(point, addresses.get(which), addresses.get(which));
		}
	};
	
	private DialogInterface.OnMultiChoiceClickListener mMultiChoiceClickListener =
		new DialogInterface.OnMultiChoiceClickListener()
	{
		public void onClick(DialogInterface dialog, int which, boolean isChecked) 
		{
			switch(which)
			{
			case 0:
				mapView.setSatellite(isChecked);
				break;
			case 1:
				mapView.setStreetView(isChecked);
				break;
			case 2:
				mapView.setTraffic(isChecked);
				break;
			default:
				break;
			}
		}
	};
}
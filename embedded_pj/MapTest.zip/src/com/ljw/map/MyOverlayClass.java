package com.ljw.map;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
class MyOverlay extends MyLocationOverlay
{
	Location mMyBeforeLocation;
	Location mMyCurrentLocation;
	Path mPath;
	Paint mPaint;
	ArrayList<MyPathLocation> mMyPathLocationArray;
	Context mContext;
	MapView mMapView;
	float mMyDistance = 0;
	public MyOverlay(Context context, MapView mapView) 
	{
		super(context, mapView);
		
		mPath = new Path();
		mPath.reset();
		mPaint = new Paint();
    	mPaint.setAntiAlias(true);
    	mPaint.setDither(true);
    	mPaint.setColor(Color.RED);
    	mPaint.setStyle(Paint.Style.STROKE);
    	mPaint.setStrokeJoin(Paint.Join.ROUND);
    	mPaint.setStrokeCap(Paint.Cap.ROUND);
    	mPaint.setStrokeWidth(3);
    	mPaint.setTextSize(20);
    	mPaint.setStyle(Paint.Style.FILL);
    	mMyPathLocationArray = new ArrayList<MyPathLocation>();
    	
    	mContext = context;
    	mMapView = mapView;
	}
	
	public void onLocationChanged(Location location)
	{
		super.onLocationChanged(location);
		Double latitude = location.getLatitude();
		Double longitude = location.getLongitude();
		Geocoder gc = new Geocoder(mContext, Locale.getDefault());
		StringBuilder sb = new StringBuilder();
		try {
			List<Address> addresses = gc.getFromLocation(latitude, longitude, 10);
			
			if(addresses.size() > 0)
			{
				Address address = addresses.get(0);
				for(int i = 0 ; i <= address.getMaxAddressLineIndex() ; i++)
				{
					if(i > 0)
						sb.append(" ");
					sb.append(address.getAddressLine(i));
				}
			}
			else
			{
				sb.append(mContext.getString(R.string.unknown_address));
			}
			((MapTest)mContext).mMyLocationEditText.setText(sb.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		mMyBeforeLocation = mMyCurrentLocation;
		mMyCurrentLocation = location;
		if(mMyBeforeLocation != null && mMyCurrentLocation != null && mMyBeforeLocation != mMyCurrentLocation)
		{
			mMyPathLocationArray.add(new MyPathLocation(mMyBeforeLocation, mMyCurrentLocation));
			
			mMyDistance += mMyCurrentLocation.distanceTo(mMyBeforeLocation);
			
			((MapTest)mContext).mMyLocationEditText.setText(String.valueOf(mMyDistance));
		}
		else 
			return;
		
	}
	
	public boolean draw(Canvas canvas, MapView mapView, boolean shadow, long when)
	{
		if(mMyBeforeLocation != null && mMyCurrentLocation != null)
		{
//			Point startPoint = new Point();
//			Point endPoint = new Point();
//			
//			mapView.getProjection().toPixels(new GeoPoint((int)(mMyBeforeLocation.getLatitude()*1E6), (int)(mMyBeforeLocation.getLongitude()*1E6)), startPoint);
//			mapView.getProjection().toPixels(new GeoPoint((int)(mMyCurrentLocation.getLatitude()*1E6), (int)(mMyCurrentLocation.getLongitude()*1E6)), endPoint);
//			
//			
			mPath.reset();
			canvas.drawPath(mPath, mPaint);
			updatePath();
//			mPath.moveTo(startPoint.x, startPoint.y);
//			mPath.lineTo(endPoint.x, endPoint.y);
			mPaint.setStyle(Paint.Style.STROKE);
			canvas.drawPath(mPath, mPaint);
			mPaint.setStyle(Paint.Style.FILL);
			canvas.drawTextOnPath(String.valueOf(mMyDistance), mPath, 0, 0, mPaint);
		}
		return super.draw(canvas, mapView, shadow, when);
	}
	
	public void updatePath()
	{
		for(int i = 0 ; i < mMyPathLocationArray.size() ; i++)
		{
			Point startPoint = new Point();
			Point endPoint = new Point();
			MyPathLocation temp = mMyPathLocationArray.get(i);
			mMapView.getProjection().toPixels(new GeoPoint((int)(temp.mMyBeforeLocation.getLatitude()*1E6), (int)(temp.mMyBeforeLocation.getLongitude()*1E6)), startPoint);
			mMapView.getProjection().toPixels(new GeoPoint((int)(temp.mMyCurrentLocation.getLatitude()*1E6), (int)(temp.mMyCurrentLocation.getLongitude()*1E6)), endPoint);
			
			Path p = new Path();
			p.reset();
			p.moveTo(startPoint.x, startPoint.y);
			p.lineTo(endPoint.x, endPoint.y);
			mPath.addPath(p);
		}
	}
	
//	public boolean onTap(GeoPoint p, MapView map)
//	{
//		if(getLastFix() == null)
//			return false;
//		Double latitude = getLastFix().getLatitude();
//		Double longitude = getLastFix().getLongitude();
//		Geocoder gc = new Geocoder(mContext, Locale.getDefault());
//		StringBuilder sb = new StringBuilder();
//		try {
//			List<Address> addresses = gc.getFromLocation(latitude, longitude, 10);
//			
//			if(addresses.size() > 0)
//			{
//				Address address = addresses.get(0);
//				for(int i = 0 ; i <= address.getMaxAddressLineIndex() ; i++)
//				{
//					if(i > 0)
//						sb.append(" ");
//					sb.append(address.getAddressLine(i));
//				}
//			}
//			else
//			{
//				return false;
//			}
//			showToast(sb.toString());
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//			return false;
//		}
//		return true;
//	}
}

class MyPathLocation
{
	public Location mMyBeforeLocation;
	public Location mMyCurrentLocation;
	
	public MyPathLocation(Location myBeforeLocation, Location myCurrentLocation)
	{
		mMyBeforeLocation = myBeforeLocation;
		mMyCurrentLocation = myCurrentLocation;
	}
}

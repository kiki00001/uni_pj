package com.ljw.map;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;

class SitesOverlay extends ItemizedOverlay<OverlayItem>
{
	private List<OverlayItem> items = new ArrayList<OverlayItem>();
	private Drawable marker = null;
	Context mContext;
	public SitesOverlay(Context context, Drawable marker) 
	{
		super(marker);
		this.marker = marker;
		mContext = context;
		//items.add( new OverlayItem(point, "a", "as"));
		
		populate();
	}
	
	public void addItem(GeoPoint point, String title, String snippet)
	{
		items.add( new OverlayItem(point, title, snippet));
		populate();
	}

	@Override
	protected OverlayItem createItem(int i) {
		return items.get(i);
	}

	@Override
	public int size() {
		return items.size();
	}
	@Override
	public void draw(Canvas canvas, MapView mapView, boolean shadow)
	{
		super.draw(canvas, mapView, shadow);
		boundCenterBottom(marker);
//		if(!mPath.isEmpty())
//		{
//			canvas.drawPath(mPath, mPaint);
//			//mPath.reset();
//		}
			
	}
	
	public boolean onTap(int index)
	{
		Geocoder gc = new Geocoder(mContext, Locale.getDefault());
		StringBuilder sb = new StringBuilder();
		try {
			List<Address> addresses = gc.getFromLocation(items.get(index).getPoint().getLatitudeE6()/1E6, items.get(index).getPoint().getLongitudeE6()/1E6, 10);
			
			if(addresses.size() > 0)
			{
				Address address = addresses.get(0);
				for(int i = 0 ; i <= address.getMaxAddressLineIndex() ; i++)
				{
					if(i > 0)
						sb.append(" ");
					sb.append(address.getAddressLine(i));
				}
			}
			else
			{
				sb.append(mContext.getString(R.string.no_address));
			}
			
			((MapTest)mContext).showToast(sb.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
}

package com.example.andlast;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class DBAdapter extends CursorAdapter{
	public DBAdapter(Context context, Cursor c) {
		super(context, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		// TODO Auto-generated method stub
		final TextView sportselect= (TextView)view.findViewById(R.id.tvsportssel);
		final TextView sportkm= (TextView)view.findViewById(R.id.tvkm);
		final TextView spendcal= (TextView)view.findViewById(R.id.tvcal);
		final ImageView image = (ImageView)view.findViewById(R.id.imageView1);
		
		image.setImageResource(R.drawable.run);
		
		sportselect.setText(cursor.getString(cursor.getColumnIndex("sposel")));
		sportkm.setText(" ��Ÿ�: "+cursor.getString(cursor.getColumnIndex("spokm")));
		spendcal.setText("  �Ҹ� Į�θ�: "+cursor.getString(cursor.getColumnIndex("spencal")));
	
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflater = LayoutInflater.from(context);
		View v = inflater.inflate(R.layout.listlay,parent,false);
		return v;
	}

	
}
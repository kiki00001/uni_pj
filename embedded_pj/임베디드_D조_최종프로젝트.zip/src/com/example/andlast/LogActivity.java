package com.example.andlast;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class LogActivity extends Activity {

	
	ListView list;
	DBHelper dbHelper;
	SQLiteDatabase db;
	Cursor cursor;
	String sql;
	
	Button btnback;

	
	/** Called when the activity is first created. */
	@Override	
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.log);
	    setTitle("�� � Log");
	
	    // TODO Auto-generated method stub
	    
	    list = (ListView)findViewById(R.id.list);
        dbHelper = new DBHelper(this);
        
        selectDB();
        
        btnback=(Button)findViewById(R.id.buttonlogBack);
        
        btnback.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}
	private void selectDB() {
		// TODO Auto-generated method stub
		
				// TODO Auto-generated method stub
				db=dbHelper.getWritableDatabase();
				sql = "SELECT * FROM TEST;";
				cursor = db.rawQuery(sql,null);
				cursor.moveToFirst();
				cursor.getCount();
				
				if(cursor.getCount()>0){
					startManagingCursor(cursor);
					DBAdapter dbAdapter = new DBAdapter(this, cursor);
					list.setAdapter(dbAdapter);
				}

	}
	
	


}

package com.example.andlast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {

	ImageButton ibWeight,ibSports,ibAlarm;
	TextView tvWeight,tvSports,tvAlarmkm,tvAlarmcal;
	View dialogView;
	EditText editKm,editCal;
	Button start,log;
	int myWeight,mysports;

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("FITNESS MONITOR ");
        
        ibWeight=(ImageButton)findViewById(R.id.imageButton1);
        ibSports=(ImageButton)findViewById(R.id.imageButton2);
        ibAlarm=(ImageButton)findViewById(R.id.imageButton3);
        
        tvWeight=(TextView)findViewById(R.id.textView_weight);
        tvSports=(TextView)findViewById(R.id.textView_sports);
        tvAlarmkm=(TextView)findViewById(R.id.textView_Alramkm);
        tvAlarmcal=(TextView)findViewById(R.id.textView_Alarmcal);
        
        start=(Button)findViewById(R.id.button1);
        log=(Button)findViewById(R.id.btlog);
        
        ibWeight.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				final String[] weightArray=new String[]{"55 ~ 65kg","65 ~ 75kg","75 ~ 85kg","85kg �̻�"};
				AlertDialog.Builder wdlg=new AlertDialog.Builder(MainActivity.this);
				wdlg.setTitle("������ ����");
				wdlg.setItems(weightArray, new DialogInterface.OnClickListener() {
					
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						tvWeight.setText(weightArray[which]);
						myWeight=which;
					}
				});
				wdlg.setPositiveButton("�ݱ�",null);
				wdlg.show();
				
			}
		});
        ibSports.setOnClickListener(new View.OnClickListener() {
			
     			public void onClick(View v) {
     				// TODO Auto-generated method stub
     				final String[] sportsArray=new String[]{"�ȱ�","����","���� �ٱ�"};
     				AlertDialog.Builder wdlg=new AlertDialog.Builder(MainActivity.this);
     				wdlg.setTitle("� ����");
     				wdlg.setItems(sportsArray, new DialogInterface.OnClickListener() {
     					
     					public void onClick(DialogInterface dialog, int which) {
     						// TODO Auto-generated method stub
     						tvSports.setText(sportsArray[which]);
     						mysports=which;
     					}
     				});
     				wdlg.setPositiveButton("�ݱ�",null);
     				wdlg.show();
     				
     			}
     		});
        ibAlarm.setOnClickListener(new View.OnClickListener() {
			
 			public void onClick(View v) {
 				// TODO Auto-generated method stub
 				dialogView=(View)View.inflate(MainActivity.this,R.layout.alarm, null);
 				
 				AlertDialog.Builder wdlg=new AlertDialog.Builder(MainActivity.this);
 				wdlg.setTitle("�˶� ����");
 				wdlg.setView(dialogView);
 				
 				
 				wdlg.setPositiveButton("Ȯ��",new DialogInterface.OnClickListener() {
					
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						editKm=(EditText)dialogView.findViewById(R.id.editText_aimkm);
						editCal=(EditText)dialogView.findViewById(R.id.editText_aimcal);
						
						tvAlarmkm.setText(editKm.getText().toString());
						tvAlarmcal.setText(editCal.getText().toString());
					}
				});
 				
 				
 				wdlg.show();
 				
 			}
 		});
        start.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent =new Intent(getApplicationContext(),MapAc.class);
				startActivity(intent);
				
					
			}
		});
        log.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent =new Intent(getApplicationContext(),LogActivity.class);
				startActivity(intent);
			}
		});
   
        
    }
   
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}


package com.example.andlast;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.maps.MapActivity;

public class MapAc extends MapActivity {

	Button finish,result;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.map_main);
	    setTitle("FITNESS MONITOR ");
	    // TODO Auto-generated method stub
	    finish=(Button)findViewById(R.id.buttonfinish);
	    result=(Button)findViewById(R.id.buttonresult);
	    
	    result.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				// ��� ���̾ƿ� ��ȭ���� ����
			}
		});
	    finish.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

}

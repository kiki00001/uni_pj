/** Automatically generated file. DO NOT MODIFY */
package anisung.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package anisung.com;

import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.widget.TabHost;

public class MainActivity extends TabActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		// startActivity(new Intent(this, SplashActivity.class));

		setContentView(R.layout.main);

		TabHost tabHost = getTabHost();

		tabHost.addTab(tabHost.newTabSpec("tab1").setIndicator("�� ��").setContent(new Intent(this, tab3.class)));

		tabHost.addTab(tabHost.newTabSpec("tab2").setIndicator("�޼���������").setContent(new Intent(this, tab2.class)));

		tabHost.addTab(tabHost.newTabSpec("tab3").setIndicator("����ó").setContent(new Intent(this, tab1.class)));

	}

}

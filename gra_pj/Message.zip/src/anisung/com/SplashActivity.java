package anisung.com;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;


public class SplashActivity extends Activity{

	
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.splash);
		
/*		
		Handler handler = new Handler(){
			
			public void handlerMessage(Message msg){
				finish();
			}
		};
		handler.sendEmptyMessageDelayed(0,3000);
*/		
		Handler h = new Handler();
		h.postDelayed(new splashhandler(), 1000);
	}
	
	class splashhandler implements Runnable {
		public void run() {
			startActivity(
					new Intent(getApplication(), MainActivity.class));
			SplashActivity.this.finish();
		}
	}
	
}

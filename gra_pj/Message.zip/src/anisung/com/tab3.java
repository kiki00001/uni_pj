package anisung.com;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class tab3 extends Activity {

	myDBHelper myHelper;
	EditText edt;
	Button btn, btn2;
	ListView listview;
	SQLiteDatabase sqlDB;
	
	ArrayList<String> list;
	ArrayAdapter<String> adapter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab3);
        
        edt = (EditText)findViewById(R.id.edt);
        btn = (Button)findViewById(R.id.insert);
        btn2 = (Button)findViewById(R.id.refresh);
        listview = (ListView)findViewById(R.id.tab3list);
 
        
        myHelper = new myDBHelper(this);
        
        
        btn.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				sqlDB = myHelper.getWritableDatabase();
				sqlDB.execSQL("INSERT INTO MgTBL VALUES(NULL, '"+edt.getText().toString()+"');");
				sqlDB.close();
				Toast.makeText(getApplicationContext(), "�Էµ�", 0).show();
				
			}
		});
        
        btn2.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				
				finish();
				
				Intent intent = new Intent(getApplicationContext(),
						MainActivity.class);
				startActivity(intent);
				
		
			}
		});
        
        sqlDB = myHelper.getReadableDatabase();
		// TODO Auto-generated method stub
		Cursor cursor;
		cursor = sqlDB.rawQuery("SELECT * FROM MgTBL;", null);
		list = new ArrayList<String>();
		 
		 while(cursor.moveToNext()){
			 list.add(cursor.getString(1));
		 }
	
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, list);
		listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
		listview.setAdapter(adapter);
		cursor.close();
		sqlDB.close();
        
       
		            
    }

    public class myDBHelper extends SQLiteOpenHelper {
    	public myDBHelper(Context context) {
    		super(context, "HSDB", null, 1);
    	}
    	@Override
    	public void onCreate(SQLiteDatabase db) {
    		// TODO Auto-generated method stub
    		db.execSQL("CREATE TABLE MgTBL(id LONG AUTO_INCREMENT PRIMARY KEY, message TEXT)");    		
    	}
    	@Override
    	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    		// TODO Auto-generated method stub
    		db.execSQL("DROP TABLE IF EXISTS MgTBL");
    		onCreate(db);
    	}
    }
 }
  

package anisung.com;

import java.util.ArrayList;

import android.app.ListActivity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class tab4 extends ListActivity implements OnClickListener {

	MyDBHelper dbHelper;
	SQLiteDatabase db;

	final String DB_NAME = "MyDB";
	final int DB_VERSION = 1;

	final String QUERY_CREATE = "CREATE TABLE MyTable"
			+ "(id LONG AUTO_INCREMENT ,written timestamp, message TEXT, PRIMARY KEY(id))";

	final String QUERY_DROP = "DROP TABLE IF EXISTS MyTable";

	final String QUERY_INSERT = "INSERT INTO MyTable "
			+ "VALUES (NULL, datatime('now', 'localtime'), ?)";

	final String QUERY_LIST = "SELECT id, written, message FROM MyTable ORDER BY id DESC";

	Button button1;
	EditText editText1;


	ArrayList<String> list;
	ArrayAdapter<String> aa;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// setContentView(R.layout.tab3);

	
		dbHelper = new MyDBHelper(this, DB_NAME, null, DB_VERSION);
		db = dbHelper.getWritableDatabase();

		// button1 = (Button) findViewById(R.id.button1);

		// editText1 = (EditText) findViewById(R.id.editText1);

	

		button1.setOnClickListener(this);

		loadView();

	}

	public class MyDBHelper extends SQLiteOpenHelper {
		public MyDBHelper(Context context, String name, CursorFactory factory,
				int version) {
			super(context, name, factory, version);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(QUERY_CREATE);
			// TODO Auto-generated method stub

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.i("tab3", "Upgarde database version from" + oldVersion + " "
					+ newVersion);
			db.execSQL(QUERY_DROP);
			onCreate(db);

			// TODO Auto-generated method stub

		}

	}

	public void onClick(View v) {
		String msg = editText1.getText().toString();
		db.execSQL(QUERY_INSERT, new String[] { msg });
		aa.insert(msg, 0);
		editText1.setText("");

	}

	private void loadView() {
		// TODO Auto-generated method stub
		Cursor c = db.rawQuery(QUERY_LIST, null);
		list = new ArrayList<String>();
		if (c.moveToFirst()) {
			do {
				list.add(c.getString(2));
			} while (c.moveToNext());

		}
		c.close();

		aa = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, list);

		setListAdapter(aa);

		// ListView list1 = (ListView)findViewById(R.id.list);

		// aa = new ArrayAdapter<String>(this,
		// android.R.layout.simple_list_item_1, list);

		// list1.setAdapter(aa);

		// setListAdapter(aa);
	}

}